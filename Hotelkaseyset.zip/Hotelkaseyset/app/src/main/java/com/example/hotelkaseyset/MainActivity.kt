package com.example.hotelroles

import android.content.ContentValues
import android.content.Context
import android.content.SharedPreferences
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    // ---------- БАЗА ДАННЫХ ----------
    class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, "hotel_premium.db", null, 4) {
        override fun onCreate(db: SQLiteDatabase) {
            db.execSQL("""
                CREATE TABLE users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT,
                    email TEXT UNIQUE,
                    password TEXT,
                    role TEXT,
                    phone TEXT,
                    avatar TEXT,
                    bonus_points INTEGER DEFAULT 0,
                    total_bookings INTEGER DEFAULT 0,
                    created_at TEXT,
                    last_login TEXT
                )
            """)
            db.execSQL("""
                CREATE TABLE hotels (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT,
                    city TEXT,
                    price REAL,
                    rating REAL,
                    description TEXT,
                    rooms INTEGER,
                    is_vip INTEGER DEFAULT 0,
                    image_url TEXT,
                    amenities TEXT
                )
            """)
            db.execSQL("""
                CREATE TABLE bookings (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    booking_number TEXT UNIQUE,
                    user_id INTEGER,
                    hotel_id INTEGER,
                    hotel_name TEXT,
                    city TEXT,
                    check_in TEXT,
                    check_out TEXT,
                    nights INTEGER,
                    guests INTEGER,
                    total_price REAL,
                    status TEXT,
                    created_at TEXT
                )
            """)
            db.execSQL("""
                CREATE TABLE favorites (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    hotel_id INTEGER,
                    UNIQUE(user_id, hotel_id)
                )
            """)
            db.execSQL("""
                CREATE TABLE bonus_transactions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    amount INTEGER,
                    type TEXT,
                    description TEXT,
                    date TEXT
                )
            """)
            db.execSQL("""
                CREATE TABLE reviews (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    hotel_id INTEGER,
                    hotel_name TEXT,
                    rating INTEGER,
                    comment TEXT,
                    date TEXT
                )
            """)

            val now = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
            // Админ
            db.execSQL("""
                INSERT INTO users(name, email, password, role, phone, avatar, bonus_points, total_bookings, created_at, last_login)
                VALUES('Александр Петров', 'admin@hotel.com', 'admin123', 'admin', '+7 (999) 123-45-67', '👑', 10000, 156, '$now', '$now')
            """)
            // VIP
            db.execSQL("""
                INSERT INTO users(name, email, password, role, phone, avatar, bonus_points, total_bookings, created_at, last_login)
                VALUES('Екатерина Смирнова', 'vip@hotel.com', 'vip123', 'vip', '+7 (999) 765-43-21', '💎', 5000, 48, '$now', '$now')
            """)
            // Обычный
            db.execSQL("""
                INSERT INTO users(name, email, password, role, phone, avatar, bonus_points, total_bookings, created_at, last_login)
                VALUES('Иван Петров', 'user@hotel.com', 'user123', 'user', '+7 (999) 111-22-33', '👤', 500, 3, '$now', '$now')
            """)
            // Отели
            db.execSQL("""
                INSERT INTO hotels(name, city, price, rating, description, rooms, is_vip, amenities)
                VALUES('Grand Plaza', 'Москва', 15000, 4.8, 'Роскошный 5-звездочный отель', 25, 0, 'Ресторан, СПА, Бассейн, Wi-Fi')
            """)
            db.execSQL("""
                INSERT INTO hotels(name, city, price, rating, description, rooms, is_vip, amenities)
                VALUES('Royal Paradise VIP', 'Москва', 45000, 4.9, 'VIP-отель с дворецким', 5, 1, 'Частный бассейн, Дворецкий, Вертолет')
            """)
        }

        override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
            db.execSQL("DROP TABLE IF EXISTS users")
            db.execSQL("DROP TABLE IF EXISTS hotels")
            db.execSQL("DROP TABLE IF EXISTS bookings")
            db.execSQL("DROP TABLE IF EXISTS favorites")
            db.execSQL("DROP TABLE IF EXISTS bonus_transactions")
            db.execSQL("DROP TABLE IF EXISTS reviews")
            onCreate(db)
        }

        fun registerUser(name: String, email: String, password: String, role: String, phone: String): Boolean {
            val db = writableDatabase
            val now = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
            val bonus = if (role == "vip") 2000 else 500
            val avatar = if (role == "vip") "💎" else if (role == "admin") "👑" else "👤"
            val cv = ContentValues().apply {
                put("name", name)
                put("email", email)
                put("password", password)
                put("role", role)
                put("phone", phone)
                put("avatar", avatar)
                put("bonus_points", bonus)
                put("total_bookings", 0)
                put("created_at", now)
                put("last_login", now)
            }
            return try {
                db.insertOrThrow("users", null, cv) != -1L
            } catch (e: Exception) {
                false
            }
        }

        fun login(email: String, password: String): User? {
            val cursor = readableDatabase.rawQuery("SELECT * FROM users WHERE email = ? AND password = ?", arrayOf(email, password))
            return if (cursor.moveToFirst()) {
                val now = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
                val cv = ContentValues().apply { put("last_login", now) }
                writableDatabase.update("users", cv, "id = ?", arrayOf(cursor.getInt(0).toString()))
                User(
                    id = cursor.getInt(0),
                    name = cursor.getString(1),
                    email = cursor.getString(2),
                    password = cursor.getString(3),
                    role = cursor.getString(4),
                    phone = cursor.getString(5),
                    avatar = cursor.getString(6) ?: if (cursor.getString(4) == "vip") "💎" else if (cursor.getString(4) == "admin") "👑" else "👤",
                    bonusPoints = cursor.getInt(7),
                    totalBookings = cursor.getInt(8),
                    createdAt = cursor.getString(9),
                    lastLogin = cursor.getString(10)
                ).also { cursor.close() }
            } else {
                cursor.close()
                null
            }
        }

        fun getAllUsers(): List<User> {
            val list = mutableListOf<User>()
            val cursor = readableDatabase.rawQuery("SELECT * FROM users", null)
            while (cursor.moveToNext()) {
                list.add(User(
                    cursor.getInt(0),
                    cursor.getString(1),
                    cursor.getString(2),
                    cursor.getString(3),
                    cursor.getString(4),
                    cursor.getString(5),
                    cursor.getString(6) ?: if (cursor.getString(4) == "vip") "💎" else if (cursor.getString(4) == "admin") "👑" else "👤",
                    cursor.getInt(7),
                    cursor.getInt(8),
                    cursor.getString(9),
                    cursor.getString(10)
                ))
            }
            cursor.close()
            return list
        }

        fun updateUserRole(userId: Int, newRole: String) {
            val cv = ContentValues().apply {
                put("role", newRole)
                put("avatar", if (newRole == "vip") "💎" else if (newRole == "admin") "👑" else "👤")
            }
            writableDatabase.update("users", cv, "id = ?", arrayOf(userId.toString()))
        }

        fun deleteUser(userId: Int) = writableDatabase.delete("users", "id = ?", arrayOf(userId.toString()))

        fun updateUserProfile(userId: Int, name: String, phone: String): Boolean {
            val cv = ContentValues().apply {
                put("name", name)
                put("phone", phone)
            }
            return writableDatabase.update("users", cv, "id = ?", arrayOf(userId.toString())) > 0
        }

        fun getAllHotels(includeVip: Boolean = true): List<Hotel> {
            val list = mutableListOf<Hotel>()
            val query = if (includeVip) "SELECT * FROM hotels" else "SELECT * FROM hotels WHERE is_vip = 0"
            val cursor = readableDatabase.rawQuery(query, null)
            while (cursor.moveToNext()) {
                list.add(Hotel(
                    cursor.getInt(0),
                    cursor.getString(1),
                    cursor.getString(2),
                    cursor.getDouble(3),
                    cursor.getDouble(4),
                    cursor.getString(5),
                    cursor.getInt(6),
                    cursor.getInt(7) == 1,
                    cursor.getString(8),
                    cursor.getString(9)
                ))
            }
            cursor.close()
            return list
        }

        fun searchHotels(query: String, city: String? = null, maxPrice: Double? = null, vipOnly: Boolean = false): List<Hotel> {
            var sql = "SELECT * FROM hotels WHERE (name LIKE ? OR city LIKE ? OR description LIKE ?)"
            val args = mutableListOf("%$query%", "%$query%", "%$query%")
            if (city != null && city.isNotEmpty()) { sql += " AND city LIKE ?"; args.add("%$city%") }
            if (maxPrice != null) { sql += " AND price <= ?"; args.add(maxPrice.toString()) }
            if (vipOnly) sql += " AND is_vip = 1"
            val list = mutableListOf<Hotel>()
            val cursor = readableDatabase.rawQuery(sql, args.toTypedArray())
            while (cursor.moveToNext()) {
                list.add(Hotel(
                    cursor.getInt(0),
                    cursor.getString(1),
                    cursor.getString(2),
                    cursor.getDouble(3),
                    cursor.getDouble(4),
                    cursor.getString(5),
                    cursor.getInt(6),
                    cursor.getInt(7) == 1,
                    cursor.getString(8),
                    cursor.getString(9)
                ))
            }
            cursor.close()
            return list
        }

        fun addHotel(hotel: Hotel): Boolean {
            val cv = ContentValues().apply {
                put("name", hotel.name)
                put("city", hotel.city)
                put("price", hotel.price)
                put("rating", hotel.rating)
                put("description", hotel.description)
                put("rooms", hotel.rooms)
                put("is_vip", if (hotel.isVip) 1 else 0)
                put("amenities", hotel.amenities)
            }
            return writableDatabase.insert("hotels", null, cv) != -1L
        }

        fun updateHotel(hotel: Hotel): Boolean {
            val cv = ContentValues().apply {
                put("name", hotel.name)
                put("city", hotel.city)
                put("price", hotel.price)
                put("rating", hotel.rating)
                put("description", hotel.description)
                put("rooms", hotel.rooms)
                put("is_vip", if (hotel.isVip) 1 else 0)
                put("amenities", hotel.amenities)
            }
            return writableDatabase.update("hotels", cv, "id = ?", arrayOf(hotel.id.toString())) > 0
        }

        fun deleteHotel(hotelId: Int) = writableDatabase.delete("hotels", "id = ?", arrayOf(hotelId.toString()))

        fun getUserBookings(userId: Int): List<Booking> {
            val list = mutableListOf<Booking>()
            val cursor = readableDatabase.rawQuery("SELECT * FROM bookings WHERE user_id = ? ORDER BY created_at DESC", arrayOf(userId.toString()))
            while (cursor.moveToNext()) {
                list.add(Booking(
                    cursor.getInt(0),
                    cursor.getString(1),
                    cursor.getInt(2),
                    cursor.getInt(3),
                    cursor.getString(4),
                    cursor.getString(5),
                    cursor.getString(6),
                    cursor.getString(7),
                    cursor.getInt(8),
                    cursor.getInt(9),
                    cursor.getDouble(10),
                    cursor.getString(11),
                    cursor.getString(12)
                ))
            }
            cursor.close()
            return list
        }

        fun getAllBookings(): List<Booking> {
            val list = mutableListOf<Booking>()
            val cursor = readableDatabase.rawQuery("SELECT * FROM bookings ORDER BY created_at DESC", null)
            while (cursor.moveToNext()) {
                list.add(Booking(
                    cursor.getInt(0),
                    cursor.getString(1),
                    cursor.getInt(2),
                    cursor.getInt(3),
                    cursor.getString(4),
                    cursor.getString(5),
                    cursor.getString(6),
                    cursor.getString(7),
                    cursor.getInt(8),
                    cursor.getInt(9),
                    cursor.getDouble(10),
                    cursor.getString(11),
                    cursor.getString(12)
                ))
            }
            cursor.close()
            return list
        }

        fun createBooking(booking: Booking): Boolean {
            val db = writableDatabase
            val bookingNumber = "BK" + System.currentTimeMillis()
            val cv = ContentValues().apply {
                put("booking_number", bookingNumber)
                put("user_id", booking.userId)
                put("hotel_id", booking.hotelId)
                put("hotel_name", booking.hotelName)
                put("city", booking.city)
                put("check_in", booking.checkIn)
                put("check_out", booking.checkOut)
                put("nights", booking.nights)
                put("guests", booking.guests)
                put("total_price", booking.totalPrice)
                put("status", "pending")
                put("created_at", SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date()))
            }
            val result = db.insert("bookings", null, cv)
            if (result != -1L) {
                val userCv = ContentValues().apply { put("total_bookings", getUserBookings(booking.userId).size + 1) }
                db.update("users", userCv, "id = ?", arrayOf(booking.userId.toString()))
                return true
            }
            return false
        }

        fun cancelBooking(bookingId: Int) {
            val cv = ContentValues().apply { put("status", "cancelled") }
            writableDatabase.update("bookings", cv, "id = ?", arrayOf(bookingId.toString()))
        }

        fun confirmBooking(bookingId: Int) {
            val cv = ContentValues().apply { put("status", "confirmed") }
            writableDatabase.update("bookings", cv, "id = ?", arrayOf(bookingId.toString()))
        }

        fun addFavorite(userId: Int, hotelId: Int): Boolean {
            val cv = ContentValues().apply {
                put("user_id", userId)
                put("hotel_id", hotelId)
            }
            return writableDatabase.insertWithOnConflict("favorites", null, cv, SQLiteDatabase.CONFLICT_IGNORE) != -1L
        }

        fun removeFavorite(userId: Int, hotelId: Int) {
            writableDatabase.delete("favorites", "user_id = ? AND hotel_id = ?", arrayOf(userId.toString(), hotelId.toString()))
        }

        fun getFavorites(userId: Int): List<Hotel> {
            val list = mutableListOf<Hotel>()
            val cursor = readableDatabase.rawQuery("""
                SELECT h.* FROM hotels h
                INNER JOIN favorites f ON h.id = f.hotel_id
                WHERE f.user_id = ?
            """, arrayOf(userId.toString()))
            while (cursor.moveToNext()) {
                list.add(Hotel(
                    cursor.getInt(0),
                    cursor.getString(1),
                    cursor.getString(2),
                    cursor.getDouble(3),
                    cursor.getDouble(4),
                    cursor.getString(5),
                    cursor.getInt(6),
                    cursor.getInt(7) == 1,
                    cursor.getString(8),
                    cursor.getString(9)
                ))
            }
            cursor.close()
            return list
        }

        fun isFavorite(userId: Int, hotelId: Int): Boolean {
            val cursor = readableDatabase.rawQuery("SELECT id FROM favorites WHERE user_id = ? AND hotel_id = ?", arrayOf(userId.toString(), hotelId.toString()))
            val exists = cursor.count > 0
            cursor.close()
            return exists
        }

        fun getUserBonusPoints(userId: Int): Int {
            val cursor = readableDatabase.rawQuery("SELECT bonus_points FROM users WHERE id = ?", arrayOf(userId.toString()))
            return if (cursor.moveToFirst()) cursor.getInt(0).also { cursor.close() } else { cursor.close(); 0 }
        }

        fun updateBonusPoints(userId: Int, points: Int) {
            val cv = ContentValues().apply { put("bonus_points", points) }
            writableDatabase.update("users", cv, "id = ?", arrayOf(userId.toString()))
        }

        fun addBonusTransaction(userId: Int, amount: Int, type: String, description: String) {
            val cv = ContentValues().apply {
                put("user_id", userId)
                put("amount", amount)
                put("type", type)
                put("description", description)
                put("date", SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date()))
            }
            writableDatabase.insert("bonus_transactions", null, cv)
        }

        fun getBonusTransactions(userId: Int): List<BonusTransaction> {
            val list = mutableListOf<BonusTransaction>()
            val cursor = readableDatabase.rawQuery("SELECT * FROM bonus_transactions WHERE user_id = ? ORDER BY date DESC", arrayOf(userId.toString()))
            while (cursor.moveToNext()) {
                list.add(BonusTransaction(
                    cursor.getInt(0),
                    cursor.getInt(1),
                    cursor.getInt(2),
                    cursor.getString(3),
                    cursor.getString(4),
                    cursor.getString(5)
                ))
            }
            cursor.close()
            return list
        }

        fun addReview(userId: Int, hotelId: Int, hotelName: String, rating: Int, comment: String): Boolean {
            val cv = ContentValues().apply {
                put("user_id", userId)
                put("hotel_id", hotelId)
                put("hotel_name", hotelName)
                put("rating", rating)
                put("comment", comment)
                put("date", SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date()))
            }
            return writableDatabase.insert("reviews", null, cv) != -1L
        }

        fun getHotelReviews(hotelId: Int): List<Review> {
            val list = mutableListOf<Review>()
            val cursor = readableDatabase.rawQuery("SELECT * FROM reviews WHERE hotel_id = ? ORDER BY date DESC", arrayOf(hotelId.toString()))
            while (cursor.moveToNext()) {
                list.add(Review(
                    cursor.getInt(0),
                    cursor.getInt(1),
                    cursor.getInt(2),
                    cursor.getString(3),
                    cursor.getInt(4),
                    cursor.getString(5),
                    cursor.getString(6)
                ))
            }
            cursor.close()
            return list
        }

        fun getStats(): String {
            val users = readableDatabase.rawQuery("SELECT COUNT(*) FROM users", null).apply { moveToFirst() }
            val hotels = readableDatabase.rawQuery("SELECT COUNT(*) FROM hotels", null).apply { moveToFirst() }
            val bookings = readableDatabase.rawQuery("SELECT COUNT(*) FROM bookings", null).apply { moveToFirst() }
            val revenue = readableDatabase.rawQuery("SELECT SUM(total_price) FROM bookings WHERE status='confirmed'", null).apply { moveToFirst() }
            val stats = """
                👥 Пользователей: ${users.getInt(0)}
                🏨 Отелей: ${hotels.getInt(0)}
                📅 Бронирований: ${bookings.getInt(0)}
                💰 Выручка: ${revenue.getDouble(0).toInt()}₽
            """.trimIndent()
            users.close(); hotels.close(); bookings.close(); revenue.close()
            return stats
        }
    }

    // ---------- DATA CLASSES ----------
    data class User(val id: Int, val name: String, val email: String, val password: String, val role: String,
                    val phone: String = "", val avatar: String = "👤", val bonusPoints: Int = 0,
                    val totalBookings: Int = 0, val createdAt: String = "", val lastLogin: String = "")
    data class Hotel(val id: Int = 0, val name: String, val city: String, val price: Double, val rating: Double,
                     val description: String, val rooms: Int, val isVip: Boolean, val imageUrl: String? = null,
                     val amenities: String? = null)
    data class Booking(val id: Int = 0, val bookingNumber: String = "", val userId: Int, val hotelId: Int,
                       val hotelName: String, val city: String, val checkIn: String, val checkOut: String,
                       val nights: Int, val guests: Int, val totalPrice: Double, val status: String,
                       val createdAt: String)
    data class BonusTransaction(val id: Int, val userId: Int, val amount: Int, val type: String,
                                val description: String, val date: String)
    data class Review(val id: Int, val userId: Int, val hotelId: Int, val hotelName: String,
                      val rating: Int, val comment: String, val date: String)

    // ---------- ГЛОБАЛЬНЫЕ ПЕРЕМЕННЫЕ ----------
    private lateinit var db: DatabaseHelper
    private lateinit var container: LinearLayout
    private lateinit var scrollView: ScrollView
    private var currentUser: User? = null
    private lateinit var sharedPref: SharedPreferences

    private val colorPrimary = Color.parseColor("#FF6B6B")
    private val colorAccent = Color.parseColor("#4ECDC4")
    private val colorVip = Color.parseColor("#9C27B0")
    private val colorAdmin = Color.parseColor("#2196F3")
    private val colorBg = Color.parseColor("#F5F7FA")
    private val colorTextPrimary = Color.parseColor("#2C3E50")
    private val colorTextSecondary = Color.parseColor("#7F8C8D")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        db = DatabaseHelper(this)
        sharedPref = getSharedPreferences("HotelPrefs", Context.MODE_PRIVATE)

        val savedEmail = sharedPref.getString("email", null)
        val savedPassword = sharedPref.getString("password", null)
        if (savedEmail != null && savedPassword != null) {
            currentUser = db.login(savedEmail, savedPassword)
        }

        scrollView = ScrollView(this).apply { setBackgroundColor(colorBg) }
        container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            setPadding(0, 0, 0, 0)
        }
        scrollView.addView(container)

        if (currentUser != null) showMainScreen() else showLoginScreen()
        setContentView(scrollView)
    }

    // ---------- UI УТИЛИТЫ ----------
    private fun createCard(content: View): CardView = CardView(this).apply {
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            .apply { setMargins(16, 8, 16, 8) }
        radius = 16f
        elevation = 4f
        setCardBackgroundColor(Color.WHITE)
        setContentPadding(20, 20, 20, 20)
        addView(LinearLayout(context).apply { orientation = LinearLayout.VERTICAL; addView(content) })
    }

    private fun createButton(text: String, bgColor: Int = colorPrimary, textColor: Int = Color.WHITE, icon: String = "", onClick: () -> Unit): Button =
        Button(this).apply {
            this.text = if (icon.isNotEmpty()) "$icon $text" else text
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                .apply { setMargins(16, 8, 16, 8) }
            setTextColor(textColor)
            setPadding(20, 16, 20, 16)
            isAllCaps = false
            textSize = 16f
            setTypeface(null, android.graphics.Typeface.BOLD)
            val gradient = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(bgColor, adjustBrightness(bgColor, -0.1f)))
                .apply { cornerRadius = 12f }
            background = gradient
            setOnClickListener { onClick() }
        }

    private fun createOutlineButton(text: String, bgColor: Int = Color.WHITE, borderColor: Int = colorPrimary, textColor: Int = colorPrimary, icon: String = "", onClick: () -> Unit): Button =
        Button(this).apply {
            this.text = if (icon.isNotEmpty()) "$icon $text" else text
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                .apply { setMargins(16, 8, 16, 8) }
            setTextColor(textColor)
            setPadding(20, 16, 20, 16)
            isAllCaps = false
            textSize = 16f
            setTypeface(null, android.graphics.Typeface.BOLD)
            val gradient = GradientDrawable().apply {
                setColor(bgColor)
                setStroke(2, borderColor)
                cornerRadius = 12f
            }
            background = gradient
            setOnClickListener { onClick() }
        }

    private fun createEditText(hint: String, isPassword: Boolean = false): EditText = EditText(this).apply {
        this.hint = hint
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            .apply { setMargins(16, 8, 16, 8) }
        setPadding(20, 16, 20, 16)
        background = ContextCompat.getDrawable(this@MainActivity, android.R.drawable.editbox_background)
        setTextColor(colorTextPrimary)
        setHintTextColor(colorTextSecondary)
        if (isPassword) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
    }

    private fun adjustBrightness(color: Int, factor: Float): Int {
        val hsv = FloatArray(3); Color.colorToHSV(color, hsv); hsv[2] = (hsv[2] * (1 + factor)).coerceIn(0f, 1f); return Color.HSVToColor(hsv)
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    private fun showDialog(title: String, message: String) = try { AlertDialog.Builder(this).setTitle(title).setMessage(message).setPositiveButton("OK", null).show() } catch (e: Exception) { toast("$title: $message") }

    // ---------- ЭКРАН ВХОДА ----------
    private fun showLoginScreen() {
        container.removeAllViews()
        val header = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(0, 80, 0, 40) }
        header.addView(TextView(this).apply { text = "🏨"; textSize = 80f })
        header.addView(TextView(this).apply { text = "Hotel Premium"; textSize = 32f; setTypeface(null, android.graphics.Typeface.BOLD); setTextColor(colorTextPrimary) })
        header.addView(TextView(this).apply { text = "Бронируйте отели по всему миру"; textSize = 14f; setTextColor(colorTextSecondary) })
        container.addView(header)

        val form = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 0, 16, 0) }
        val etEmail = createEditText("Email").apply { setText("user@hotel.com") }
        val etPass = createEditText("Пароль", true).apply { setText("user123") }
        form.addView(etEmail); form.addView(etPass)

        val forgotLayout = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END; layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { setMargins(16, 0, 16, 16) } }
        forgotLayout.addView(TextView(this).apply { text = "Забыли пароль?"; textSize = 14f; setTextColor(colorPrimary); setTypeface(null, android.graphics.Typeface.BOLD); setOnClickListener { showForgotPasswordDialog() } })
        form.addView(forgotLayout)

        form.addView(createButton("🔐 Войти", colorPrimary) {
            val email = etEmail.text.toString().trim(); val pass = etPass.text.toString().trim()
            if (email.isEmpty() || pass.isEmpty()) { toast("Заполните все поля"); return@createButton }
            val user = db.login(email, pass)
            if (user != null) {
                currentUser = user
                sharedPref.edit().putString("email", email).putString("password", pass).apply()
                showMainScreen()
            } else toast("Неверный email или пароль")
        })

        form.addView(createOutlineButton("📝 Создать аккаунт", Color.WHITE, colorPrimary, colorPrimary) { showRegisterScreen() })
        container.addView(form)

        val socialLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 32, 16, 16) }
        socialLayout.addView(TextView(this).apply { text = "Или войдите через"; textSize = 14f; setTextColor(colorTextSecondary); gravity = Gravity.CENTER_HORIZONTAL })
        val socialButtons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_HORIZONTAL; layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { setMargins(0, 16, 0, 0) } }
        socialButtons.addView(Button(this).apply { text = "G"; setTextColor(Color.WHITE); setBackgroundColor(Color.parseColor("#DB4437")); setPadding(0, 12, 0, 12); layoutParams = LinearLayout.LayoutParams(100, LinearLayout.LayoutParams.WRAP_CONTENT).apply { setMargins(8, 0, 8, 0) }; setOnClickListener { toast("Вход через Google (демо)") } })
        socialButtons.addView(Button(this).apply { text = "f"; setTextColor(Color.WHITE); setBackgroundColor(Color.parseColor("#4267B2")); setPadding(0, 12, 0, 12); layoutParams = LinearLayout.LayoutParams(100, LinearLayout.LayoutParams.WRAP_CONTENT).apply { setMargins(8, 0, 8, 0) }; setOnClickListener { toast("Вход через Facebook (демо)") } })
        socialLayout.addView(socialButtons); container.addView(socialLayout)

        val testLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 32, 16, 32) }
        testLayout.addView(TextView(this).apply { text = "Тестовые аккаунты"; textSize = 16f; setTypeface(null, android.graphics.Typeface.BOLD); setTextColor(colorTextPrimary) })
        listOf("👑 Админ: admin@hotel.com / admin123", "💎 VIP: vip@hotel.com / vip123", "👤 Обычный: user@hotel.com / user123").forEach { account ->
            testLayout.addView(TextView(this).apply { text = account; textSize = 13f; setTextColor(colorTextSecondary); setPadding(0, 4, 0, 4) })
        }
        container.addView(testLayout)
    }

    private fun showForgotPasswordDialog() {
        val etEmail = EditText(this).apply { hint = "Введите ваш email"; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS }
        AlertDialog.Builder(this).setTitle("🔐 Восстановление пароля").setMessage("Мы отправим ссылку для сброса пароля на ваш email")
            .setView(etEmail, 32, 16, 32, 16).setPositiveButton("Отправить") { _, _ ->
                val email = etEmail.text.toString().trim(); if (email.isNotEmpty()) toast("Ссылка отправлена на $email (демо)") else toast("Введите email")
            }.setNegativeButton("Отмена", null).show()
    }

    // ---------- ЭКРАН РЕГИСТРАЦИИ ----------
    private fun showRegisterScreen() {
        container.removeAllViews()
        val header = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(0, 60, 0, 40) }
        header.addView(TextView(this).apply { text = "📝"; textSize = 64f })
        header.addView(TextView(this).apply { text = "Создать аккаунт"; textSize = 28f; setTypeface(null, android.graphics.Typeface.BOLD); setTextColor(colorTextPrimary) })
        container.addView(header)

        val form = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 0, 16, 0) }
        val etName = createEditText("Имя *")
        val etEmail = createEditText("Email *")
        val etPhone = createEditText("Телефон *")
        val etPass = createEditText("Пароль *", true)
        val etConfirm = createEditText("Подтвердите пароль *", true)
        form.addView(etName); form.addView(etEmail); form.addView(etPhone); form.addView(etPass); form.addView(etConfirm)

        val roleLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { setMargins(16, 16, 16, 8) } }
        roleLayout.addView(TextView(this).apply { text = "Тип аккаунта"; textSize = 16f; setTypeface(null, android.graphics.Typeface.BOLD); setTextColor(colorTextPrimary) })
        val rgRole = RadioGroup(this).apply { orientation = LinearLayout.HORIZONTAL }
        rgRole.addView(RadioButton(this).apply { text = "👤 Обычный"; id = View.generateViewId(); isChecked = true; setPadding(8, 8, 24, 8); setTextColor(colorTextPrimary) })
        rgRole.addView(RadioButton(this).apply { text = "💎 VIP"; id = View.generateViewId(); setPadding(8, 8, 24, 8); setTextColor(colorTextPrimary) })
        roleLayout.addView(rgRole); form.addView(roleLayout)

        val termsLayout = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { setMargins(16, 16, 16, 8) } }
        val cbTerms = CheckBox(this).apply { text = "Я принимаю условия использования"; textSize = 12f; setTextColor(colorTextSecondary); isChecked = true }
        termsLayout.addView(cbTerms); form.addView(termsLayout)

        form.addView(createButton("✅ Зарегистрироваться", colorAccent) {
            val name = etName.text.toString().trim(); val email = etEmail.text.toString().trim(); val phone = etPhone.text.toString().trim()
            val pass = etPass.text.toString().trim(); val confirm = etConfirm.text.toString().trim()
            val role = if ((rgRole.getChildAt(0) as RadioButton).isChecked) "user" else "vip"
            if (name.isEmpty() || email.isEmpty() || phone.isEmpty() || pass.isEmpty()) { toast("Заполните все поля"); return@createButton }
            if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) { toast("Введите корректный email"); return@createButton }
            if (pass.length < 6) { toast("Пароль должен содержать минимум 6 символов"); return@createButton }
            if (pass != confirm) { toast("Пароли не совпадают"); return@createButton }
            if (!cbTerms.isChecked) { toast("Необходимо принять условия"); return@createButton }
            if (db.registerUser(name, email, pass, role, phone)) { toast("Регистрация успешна! Теперь войдите."); showLoginScreen() }
            else toast("Ошибка: Email уже используется")
        })

        form.addView(createOutlineButton("⬅️ Уже есть аккаунт", Color.WHITE, colorTextSecondary, colorTextSecondary, "⬅️") { showLoginScreen() })
        container.addView(form)
    }

    // ---------- ГЛАВНЫЙ ЭКРАН (БЕЗОПАСНЫЕ ВЫЗОВЫ) ----------
    private fun showMainScreen() {
        container.removeAllViews()
        val user = currentUser ?: run { showLoginScreen(); return }

        val topBar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(16, 40, 16, 16) }
        topBar.addView(TextView(this).apply { text = user.avatar; textSize = 40f; setPadding(0, 0, 16, 0) })
        val greetingLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f) }
        greetingLayout.addView(TextView(this).apply { text = "Привет, ${user.name.split(" ").firstOrNull() ?: "Гость"}!"; textSize = 18f; setTypeface(null, android.graphics.Typeface.BOLD); setTextColor(colorTextPrimary) })
        greetingLayout.addView(TextView(this).apply { text = when (user.role) { "admin" -> "Администратор"; "vip" -> "VIP-клиент"; else -> "Клиент" }; textSize = 14f; setTextColor(colorTextSecondary) })
        topBar.addView(greetingLayout)
        topBar.addView(Button(this).apply { text = "🔔"; setBackgroundColor(Color.TRANSPARENT); setOnClickListener { toast("Новых уведомлений нет") } })
        container.addView(topBar)

        val tabLayout = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(0, 16, 0, 16) }
        val tabs = if (user.role == "admin") listOf("📊 Статистика", "👥 Пользователи", "🏨 Отели", "📋 Брони")
        else listOf("🔍 Поиск", "❤️ Избранное", "👤 Профиль")
        val tabButtons = tabs.map { title ->
            Button(tabLayout.context).apply {
                text = title
                setTextColor(if (title == tabs[0]) colorPrimary else colorTextSecondary)
                setBackgroundColor(Color.TRANSPARENT)
                textSize = 14f; isAllCaps = false
                setTypeface(null, if (title == tabs[0]) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL)
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                tabLayout.addView(this)
            }
        }
        container.addView(tabLayout)

        val contentContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; id = View.generateViewId() }
        container.addView(contentContainer)

        when (user.role) {
            "admin" -> {
                tabButtons[0].setOnClickListener { resetTabColors(tabButtons, 0, colorPrimary); showAdminStatsContent(contentContainer) }
                tabButtons[1].setOnClickListener { resetTabColors(tabButtons, 1, colorPrimary); showUserManagementContent(contentContainer) }
                tabButtons[2].setOnClickListener { resetTabColors(tabButtons, 2, colorPrimary); showHotelManagementContent(contentContainer) }
                tabButtons[3].setOnClickListener { resetTabColors(tabButtons, 3, colorPrimary); showAllBookingsContent(contentContainer) }
                showAdminStatsContent(contentContainer)
            }
            else -> {
                tabButtons[0].setOnClickListener { resetTabColors(tabButtons, 0, colorPrimary); showSearchContent(contentContainer) }
                tabButtons[1].setOnClickListener { resetTabColors(tabButtons, 1, colorPrimary); showFavoritesContent(contentContainer) }
                tabButtons[2].setOnClickListener { resetTabColors(tabButtons, 2, colorPrimary); showProfileContent(contentContainer) }
                showSearchContent(contentContainer)
            }
        }

        container.addView(createButton("🚪 Выйти", Color.parseColor("#F44336"), icon = "🚪") {
            sharedPref.edit().clear().apply(); currentUser = null; showLoginScreen()
        })
    }

    private fun resetTabColors(tabs: List<Button>, activeIndex: Int, activeColor: Int) {
        tabs.forEachIndexed { index, btn -> btn.setTextColor(if (index == activeIndex) activeColor else colorTextSecondary)
            btn.setTypeface(null, if (index == activeIndex) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL) }
    }

    // ---------- АДМИН ----------
    private fun showAdminStatsContent(container: LinearLayout) {
        container.removeAllViews()
        container.addView(createCard(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(TextView(context).apply { text = "📊 Общая статистика"; textSize = 20f; setTypeface(null, android.graphics.Typeface.BOLD); setTextColor(colorAdmin); setPadding(0, 0, 0, 16) })
            addView(TextView(context).apply { text = db.getStats(); textSize = 16f; setTextColor(colorTextPrimary) })
        }))
        container.addView(createButton("➕ Добавить клиента", colorAdmin, icon = "➕") { showAddUserDialog() })
        container.addView(createButton("📊 Детальная статистика", colorAdmin) { showDetailedStats() })
    }

    private fun showUserManagementContent(container: LinearLayout) {
        container.removeAllViews()
        container.addView(TextView(this).apply { text = "👥 Управление пользователями"; textSize = 20f; setTypeface(null, android.graphics.Typeface.BOLD); setTextColor(colorAdmin); setPadding(16, 16, 16, 16) })
        db.getAllUsers().forEach { user ->
            if (user.id != currentUser?.id) {
                val userCard = createCard(LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    val headerRow = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
                    headerRow.addView(TextView(context).apply { text = user.avatar; textSize = 24f; setPadding(0, 0, 16, 0) })
                    headerRow.addView(TextView(context).apply { text = "${user.name}\n${user.email}"; textSize = 16f; setTextColor(colorTextPrimary) })
                    addView(headerRow)
                    addView(TextView(context).apply { text = "📞 ${user.phone} | Роль: ${user.role}"; textSize = 14f; setTextColor(colorTextSecondary); setPadding(0, 8, 0, 8) })
                    val actionsRow = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
                    val roles = listOf("user", "vip", "admin")
                    val roleNames = listOf("👤 Обычный", "💎 VIP", "👑 Админ")
                    val spinner = Spinner(context).apply {
                        adapter = ArrayAdapter(context, android.R.layout.simple_spinner_item, roleNames).also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
                        setSelection(roles.indexOf(user.role))
                        onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                                if (roles[pos] != user.role) { db.updateUserRole(user.id, roles[pos]); toast("Роль изменена на ${roleNames[pos]}") }
                            }
                            override fun onNothingSelected(p: AdapterView<*>?) {}
                        }
                    }
                    actionsRow.addView(spinner)
                    actionsRow.addView(Button(context).apply {
                        text = "🗑️"; setBackgroundColor(Color.TRANSPARENT); setTextColor(Color.RED)
                        setOnClickListener { AlertDialog.Builder(this@MainActivity).setTitle("Удаление пользователя").setMessage("Удалить ${user.name}?")
                            .setPositiveButton("Да") { _, _ -> db.deleteUser(user.id); toast("Пользователь удалён"); showUserManagementContent(container) }
                            .setNegativeButton("Нет", null).show() }
                    })
                    addView(actionsRow)
                })
                container.addView(userCard)
            }
        }
        container.addView(createOutlineButton("➕ Добавить клиента", Color.WHITE, colorAdmin, colorAdmin, "➕") { showAddUserDialog() })
    }

    private fun showHotelManagementContent(container: LinearLayout) {
        container.removeAllViews()
        container.addView(TextView(this).apply { text = "🏨 Управление отелями"; textSize = 20f; setTypeface(null, android.graphics.Typeface.BOLD); setTextColor(colorAdmin); setPadding(16, 16, 16, 16) })
        db.getAllHotels().forEach { hotel ->
            val hotelCard = createCard(LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                addView(TextView(context).apply { text = "${if (hotel.isVip) "💎 " else "🏨 "}${hotel.name}"; textSize = 18f; setTypeface(null, android.graphics.Typeface.BOLD); setTextColor(colorTextPrimary) })
                addView(TextView(context).apply { text = "📍 ${hotel.city} | ⭐ ${hotel.rating} | 💰 ${hotel.price}₽"; textSize = 14f; setTextColor(colorTextSecondary) })
                val actionsRow = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
                actionsRow.addView(Button(context).apply { text = "✏️ Редактировать"; setOnClickListener { showEditHotelDialog(hotel) } })
                actionsRow.addView(Button(context).apply {
                    text = "🗑️ Удалить"; setTextColor(Color.RED)
                    setOnClickListener { AlertDialog.Builder(this@MainActivity).setTitle("Удаление отеля").setMessage("Удалить ${hotel.name}?")
                        .setPositiveButton("Да") { _, _ -> db.deleteHotel(hotel.id); toast("Отель удалён"); showHotelManagementContent(container) }
                        .setNegativeButton("Нет", null).show() }
                })
                addView(actionsRow)
            })
            container.addView(hotelCard)
        }
        container.addView(createButton("➕ Добавить отель", colorAdmin, icon = "➕") { showAddHotelDialog() })
    }

    private fun showAllBookingsContent(container: LinearLayout) {
        container.removeAllViews()
        container.addView(TextView(this).apply { text = "📋 Все бронирования"; textSize = 20f; setTypeface(null, android.graphics.Typeface.BOLD); setTextColor(colorAdmin); setPadding(16, 16, 16, 16) })
        val bookings = db.getAllBookings()
        if (bookings.isEmpty()) {
            container.addView(TextView(this).apply { text = "Нет бронирований"; textSize = 16f; setTextColor(colorTextSecondary); setPadding(16, 16, 16, 16) })
        } else {
            bookings.forEach { booking ->
                val card = createCard(LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    val statusEmoji = when (booking.status) { "confirmed" -> "✅"; "pending" -> "⏳"; "cancelled" -> "❌"; else -> "📅" }
                    addView(TextView(context).apply { text = "$statusEmoji ${booking.hotelName} (${booking.city})"; textSize = 18f; setTypeface(null, android.graphics.Typeface.BOLD); setTextColor(colorTextPrimary) })
                    addView(TextView(context).apply {
                        text = "Бронь #${booking.bookingNumber}\n📅 ${booking.checkIn} – ${booking.checkOut} (${booking.nights} ночей)\n👥 ${booking.guests} гостей\n💰 ${booking.totalPrice.toInt()}₽"
                        textSize = 14f; setTextColor(colorTextSecondary); setPadding(0, 8, 0, 8)
                    })
                    if (booking.status == "pending") {
                        addView(Button(context).apply { text = "✅ Подтвердить"; setOnClickListener { db.confirmBooking(booking.id); toast("Бронирование подтверждено"); showAllBookingsContent(container) } })
                    }
                })
                container.addView(card)
            }
        }
    }

    private fun showDetailedStats() {
        val users = db.getAllUsers(); val hotels = db.getAllHotels(); val bookings = db.getAllBookings()
        val vipCount = users.count { it.role == "vip" }; val adminCount = users.count { it.role == "admin" }; val userCount = users.count { it.role == "user" }
        val vipHotels = hotels.count { it.isVip }; val confirmed = bookings.count { it.status == "confirmed" }; val pending = bookings.count { it.status == "pending" }; val cancelled = bookings.count { it.status == "cancelled" }
        val stats = """
            👥 ПОЛЬЗОВАТЕЛИ
            • Всего: ${users.size}
            • Админы: $adminCount
            • VIP: $vipCount
            • Обычные: $userCount
            
            🏨 ОТЕЛИ
            • Всего: ${hotels.size}
            • VIP: $vipHotels
            • Обычные: ${hotels.size - vipHotels}
            
            📅 БРОНИРОВАНИЯ
            • Всего: ${bookings.size}
            • Подтверждено: $confirmed
            • Ожидают: $pending
            • Отменено: $cancelled
        """.trimIndent()
        showDialog("📊 Детальная статистика", stats)
    }

    // ---------- ПОЛЬЗОВАТЕЛЬ ----------
    private fun showSearchContent(container: LinearLayout) {
        container.removeAllViews()
        val user = currentUser ?: return

        val searchLayout = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(16, 16, 16, 16) }
        val etSearch = EditText(this).apply { hint = "Название отеля или город"; layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f); setPadding(16, 12, 16, 12); setBackgroundResource(android.R.drawable.editbox_background) }
        searchLayout.addView(etSearch)
        searchLayout.addView(Button(this).apply { text = "🔍"; setBackgroundColor(colorPrimary); setTextColor(Color.WHITE); setPadding(16, 12, 16, 12)
            setOnClickListener { if (etSearch.text.toString().isNotEmpty()) showSearchResults(container, etSearch.text.toString()) else showAllHotels(container) } })
        container.addView(searchLayout)

        val filtersLayout = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(16, 0, 16, 16) }
        filtersLayout.addView(TextView(this).apply { text = "Фильтр:"; setTextColor(colorTextSecondary); setPadding(0, 0, 8, 0) })
        filtersLayout.addView(Button(this).apply {
            text = "💎 VIP"; setBackgroundColor(if (user.role == "vip") colorVip else Color.LTGRAY); setTextColor(if (user.role == "vip") Color.WHITE else colorTextSecondary); textSize = 12f; setPadding(12, 6, 12, 6)
            setOnClickListener { if (user.role == "vip") showVipHotelsOnly(container) else toast("Только для VIP-клиентов") }
        })
        filtersLayout.addView(Button(this).apply {
            text = "💰 До 20000"; setBackgroundColor(Color.LTGRAY); setTextColor(colorTextSecondary); textSize = 12f; setPadding(12, 6, 12, 6)
            setOnClickListener { showHotelsByMaxPrice(container, 20000.0) }
        })
        container.addView(filtersLayout)

        showAllHotels(container)
    }

    private fun showAllHotels(container: LinearLayout) {
        val user = currentUser ?: return
        val hotels = db.getAllHotels(includeVip = user.role == "vip")
        displayHotels(container, hotels)
    }

    private fun showVipHotelsOnly(container: LinearLayout) {
        displayHotels(container, db.getAllHotels().filter { it.isVip })
    }

    private fun showHotelsByMaxPrice(container: LinearLayout, maxPrice: Double) {
        val user = currentUser ?: return
        val hotels = db.getAllHotels(includeVip = user.role == "vip").filter { it.price <= maxPrice }
        displayHotels(container, hotels)
    }

    private fun showSearchResults(container: LinearLayout, query: String) {
        val user = currentUser ?: return
        val hotels = db.searchHotels(query, vipOnly = user.role == "vip")
        displayHotels(container, hotels)
    }

    private fun displayHotels(container: LinearLayout, hotels: List<Hotel>) {
        val user = currentUser ?: return
        while (container.childCount > 2) container.removeViewAt(container.childCount - 1)
        if (hotels.isEmpty()) {
            container.addView(TextView(this).apply { text = "Отели не найдены"; textSize = 16f; setTextColor(colorTextSecondary); gravity = Gravity.CENTER_HORIZONTAL; setPadding(16, 32, 16, 32) })
            return
        }
        hotels.forEach { hotel ->
            val card = createCard(LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                val headerRow = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
                headerRow.addView(TextView(context).apply { text = if (hotel.isVip) "💎 " else "🏨 "; textSize = 24f })
                headerRow.addView(TextView(context).apply { text = hotel.name; textSize = 18f; setTypeface(null, android.graphics.Typeface.BOLD); setTextColor(colorTextPrimary); layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f) })
                headerRow.addView(TextView(context).apply { text = "⭐ ${hotel.rating}"; textSize = 16f; setTypeface(null, android.graphics.Typeface.BOLD); setTextColor(Color.parseColor("#FFC107")) })
                addView(headerRow)
                val infoRow = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
                infoRow.addView(TextView(context).apply { text = "📍 ${hotel.city}"; textSize = 14f; setTextColor(colorTextSecondary); layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f) })
                infoRow.addView(TextView(context).apply { text = "💰 ${hotel.price}₽"; textSize = 16f; setTypeface(null, android.graphics.Typeface.BOLD); setTextColor(colorPrimary) })
                addView(infoRow)
                val actionsRow = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
                actionsRow.addView(Button(context).apply { text = "Подробнее"; setOnClickListener { showHotelDetails(hotel) } })
                val isFav = db.isFavorite(user.id, hotel.id)
                actionsRow.addView(Button(context).apply {
                    text = if (isFav) "❤️ В избранном" else "🤍 В избранное"
                    setOnClickListener {
                        if (db.isFavorite(user.id, hotel.id)) { db.removeFavorite(user.id, hotel.id); toast("Удалено из избранного"); (this as Button).text = "🤍 В избранное" }
                        else { db.addFavorite(user.id, hotel.id); toast("Добавлено в избранное"); this.text = "❤️ В избранном" }
                    }
                })
                addView(actionsRow)
            })
            card.setOnClickListener { showHotelDetails(hotel) }
            container.addView(card)
        }
    }

    private fun showFavoritesContent(container: LinearLayout) {
        container.removeAllViews()
        val user = currentUser ?: return
        container.addView(TextView(this).apply { text = "❤️ Избранное"; textSize = 24f; setTypeface(null, android.graphics.Typeface.BOLD); setTextColor(colorTextPrimary); setPadding(16, 16, 16, 16) })
        val favorites = db.getFavorites(user.id)
        if (favorites.isEmpty()) {
            container.addView(TextView(this).apply { text = "У вас пока нет избранных отелей"; textSize = 16f; setTextColor(colorTextSecondary); gravity = Gravity.CENTER_HORIZONTAL; setPadding(16, 64, 16, 64) })
        } else {
            favorites.forEach { hotel ->
                val card = createCard(LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    addView(TextView(context).apply { text = "${if (hotel.isVip) "💎 " else "🏨 "}${hotel.name}"; textSize = 18f; setTypeface(null, android.graphics.Typeface.BOLD); setTextColor(colorTextPrimary) })
                    addView(TextView(context).apply { text = "📍 ${hotel.city} | ⭐ ${hotel.rating} | 💰 ${hotel.price}₽"; textSize = 14f; setTextColor(colorTextSecondary) })
                    addView(Button(context).apply { text = "🗑️ Удалить"; setTextColor(Color.RED); setOnClickListener { db.removeFavorite(user.id, hotel.id); toast("Удалено из избранного"); showFavoritesContent(container) } })
                })
                card.setOnClickListener { showHotelDetails(hotel) }
                container.addView(card)
            }
        }
    }

    private fun showProfileContent(container: LinearLayout) {
        container.removeAllViews()
        val user = currentUser ?: return

        val profileHeader = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(16, 32, 16, 16) }
        profileHeader.addView(TextView(this).apply { text = user.avatar; textSize = 64f; setPadding(0, 0, 24, 0) })
        val nameLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        nameLayout.addView(TextView(this).apply { text = user.name; textSize = 24f; setTypeface(null, android.graphics.Typeface.BOLD); setTextColor(colorTextPrimary) })
        nameLayout.addView(TextView(this).apply { text = when (user.role) { "admin" -> "Администратор"; "vip" -> "VIP-клиент"; else -> "Клиент" }; textSize = 16f; setTextColor(colorTextSecondary) })
        profileHeader.addView(nameLayout); container.addView(profileHeader)

        container.addView(createCard(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(TextView(context).apply { text = "💰 Бонусный счет"; textSize = 18f; setTypeface(null, android.graphics.Typeface.BOLD); setTextColor(colorTextPrimary) })
            val bonusRow = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            bonusRow.addView(TextView(context).apply { text = "${user.bonusPoints}"; textSize = 36f; setTypeface(null, android.graphics.Typeface.BOLD); setTextColor(colorAccent) })
            bonusRow.addView(TextView(context).apply { text = " баллов"; textSize = 18f; setTextColor(colorTextSecondary); setPadding(8, 0, 0, 0) })
            addView(bonusRow)
            addView(TextView(context).apply { text = "1 балл = 1 рубль при следующем бронировании"; textSize = 12f; setTextColor(colorTextSecondary) })
        }))

        container.addView(createCard(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(TextView(context).apply { text = "📋 Личные данные"; textSize = 18f; setTypeface(null, android.graphics.Typeface.BOLD); setTextColor(colorTextPrimary) })
            addView(TextView(context).apply { text = "📧 ${user.email}"; textSize = 14f; setTextColor(colorTextSecondary); setPadding(0, 8, 0, 4) })
            addView(TextView(context).apply { text = "📞 ${user.phone}"; textSize = 14f; setTextColor(colorTextSecondary); setPadding(0, 4, 0, 4) })
            addView(TextView(context).apply { text = "📅 Зарегистрирован: ${user.createdAt.split(" ")[0]}"; textSize = 12f; setTextColor(colorTextSecondary); setPadding(0, 4, 0, 4) })
            addView(TextView(context).apply { text = "📅 Последний вход: ${user.lastLogin.split(" ")[0]}"; textSize = 12f; setTextColor(colorTextSecondary); setPadding(0, 4, 0, 4) })
            addView(Button(context).apply { text = "✏️ Редактировать профиль"; setOnClickListener { showEditProfileDialog() } })
        }))

        val bookings = db.getUserBookings(user.id)
        container.addView(createCard(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(TextView(context).apply { text = "📅 Мои бронирования (${bookings.size})"; textSize = 18f; setTypeface(null, android.graphics.Typeface.BOLD); setTextColor(colorTextPrimary) })
            if (bookings.isEmpty()) addView(TextView(context).apply { text = "У вас пока нет бронирований"; textSize = 14f; setTextColor(colorTextSecondary); setPadding(0, 8, 0, 0) })
            else {
                bookings.take(3).forEach { booking ->
                    val statusEmoji = when (booking.status) { "confirmed" -> "✅"; "pending" -> "⏳"; "cancelled" -> "❌"; else -> "📅" }
                    addView(TextView(context).apply { text = "$statusEmoji ${booking.hotelName}\n   ${booking.checkIn} – ${booking.checkOut}, ${booking.guests} гостей"; textSize = 14f; setTextColor(colorTextSecondary); setPadding(0, 8, 0, 8) })
                }
                if (bookings.size > 3) addView(Button(context).apply { text = "Показать все (${bookings.size})"; setOnClickListener { showAllUserBookings() } })
            }
        }))
    }

    private fun showEditProfileDialog() {
        val user = currentUser ?: return
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 24, 32, 24) }
        layout.addView(EditText(this).apply { hint = "Имя"; setText(user.name) })
        layout.addView(EditText(this).apply { hint = "Телефон"; setText(user.phone) })
        AlertDialog.Builder(this).setTitle("✏️ Редактировать профиль").setView(layout)
            .setPositiveButton("Сохранить") { _, _ ->
                val newName = (layout.getChildAt(0) as EditText).text.toString()
                val newPhone = (layout.getChildAt(1) as EditText).text.toString()
                if (newName.isNotEmpty() && newPhone.isNotEmpty()) {
                    if (db.updateUserProfile(user.id, newName, newPhone)) {
                        currentUser = user.copy(name = newName, phone = newPhone)
                        toast("Профиль обновлен"); showMainScreen()
                    } else toast("Ошибка обновления")
                } else toast("Заполните все поля")
            }.setNegativeButton("Отмена", null).show()
    }

    private fun showAllUserBookings() {
        val user = currentUser ?: return
        val bookings = db.getUserBookings(user.id)
        if (bookings.isEmpty()) { showDialog("Мои бронирования", "У вас нет бронирований"); return }
        val list = bookings.joinToString("\n\n") { booking ->
            val emoji = when (booking.status) { "confirmed" -> "✅"; "pending" -> "⏳"; "cancelled" -> "❌"; else -> "📅" }
            "$emoji ${booking.hotelName}\n📍 ${booking.city}\n📅 ${booking.checkIn} – ${booking.checkOut} (${booking.nights} ночей)\n👥 ${booking.guests} гостей\n💰 ${booking.totalPrice.toInt()}₽\n📊 Статус: ${booking.status}"
        }
        showDialog("📅 Все мои бронирования", list)
    }

    // ---------- ДЕТАЛИ ОТЕЛЯ ----------
    private fun showHotelDetails(hotel: Hotel) {
        val user = currentUser ?: return
        container.removeAllViews()
        val header = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 32, 16, 16) }
        header.addView(TextView(this).apply { text = if (hotel.isVip) "💎 ${hotel.name}" else "🏨 ${hotel.name}"; textSize = 28f; setTypeface(null, android.graphics.Typeface.BOLD); setTextColor(colorTextPrimary) })
        header.addView(TextView(this).apply { text = "📍 ${hotel.city} | ⭐ ${hotel.rating} | 💰 ${hotel.price}₽/ночь"; textSize = 16f; setTextColor(colorTextSecondary); setPadding(0, 8, 0, 0) })
        container.addView(header)

        val imagePlaceholder = CardView(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 200).apply { setMargins(16, 8, 16, 16) }
            radius = 12f; setCardBackgroundColor(Color.parseColor("#E0E0E0"))
            addView(TextView(context).apply { text = "🏨 ${hotel.name}"; textSize = 24f; gravity = Gravity.CENTER; setTextColor(Color.WHITE) })
        }
        container.addView(imagePlaceholder)

        container.addView(createCard(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(TextView(context).apply { text = "📝 Описание"; textSize = 20f; setTypeface(null, android.graphics.Typeface.BOLD); setTextColor(colorTextPrimary) })
            addView(TextView(context).apply { text = hotel.description; textSize = 14f; setTextColor(colorTextSecondary); setPadding(0, 8, 0, 0) })
        }))

        if (hotel.amenities != null) {
            container.addView(createCard(LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                addView(TextView(context).apply { text = "✨ Удобства"; textSize = 20f; setTypeface(null, android.graphics.Typeface.BOLD); setTextColor(colorTextPrimary) })
                hotel.amenities.split(",").forEach { amenity ->
                    addView(TextView(context).apply { text = "• ${amenity.trim()}"; textSize = 14f; setTextColor(colorTextSecondary); setPadding(0, 4, 0, 4) })
                }
            }))
        }

        val reviews = db.getHotelReviews(hotel.id)
        container.addView(createCard(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(TextView(context).apply { text = "⭐ Отзывы (${reviews.size})"; textSize = 20f; setTypeface(null, android.graphics.Typeface.BOLD); setTextColor(colorTextPrimary) })
            if (reviews.isEmpty()) addView(TextView(context).apply { text = "Пока нет отзывов"; textSize = 14f; setTextColor(colorTextSecondary); setPadding(0, 8, 0, 0) })
            else {
                reviews.take(3).forEach { review ->
                    addView(TextView(context).apply { text = "👤 Пользователь ${review.userId}\n   ${"⭐".repeat(review.rating)}${"☆".repeat(5 - review.rating)}\n   \"${review.comment}\"\n   📅 ${review.date.split(" ")[0]}"; textSize = 14f; setTextColor(colorTextSecondary); setPadding(0, 8, 0, 8) })
                }
            }
            addView(Button(context).apply { text = "✏️ Написать отзыв"; setOnClickListener { showAddReviewDialog(hotel) } })
        }))

        container.addView(createCard(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(TextView(context).apply { text = "📅 Забронировать"; textSize = 20f; setTypeface(null, android.graphics.Typeface.BOLD); setTextColor(colorTextPrimary) })
            val etCheckIn = EditText(context).apply { hint = "Дата заезда (ГГГГ-ММ-ДД)"; setText("2026-05-01") }; addView(etCheckIn)
            val etCheckOut = EditText(context).apply { hint = "Дата выезда"; setText("2026-05-05") }; addView(etCheckOut)
            val etGuests = EditText(context).apply { hint = "Гостей"; setText("2"); inputType = InputType.TYPE_CLASS_NUMBER }; addView(etGuests)
            addView(Button(context).apply {
                text = "✅ Забронировать"
                setOnClickListener {
                    try {
                        val checkIn = etCheckIn.text.toString(); val checkOut = etCheckOut.text.toString(); val guests = etGuests.text.toString().toInt()
                        val nights = 1; val total = hotel.price * nights
                        val booking = Booking(userId = user.id, hotelId = hotel.id, hotelName = hotel.name, city = hotel.city,
                            checkIn = checkIn, checkOut = checkOut, nights = nights, guests = guests, totalPrice = total,
                            status = "pending", createdAt = "", bookingNumber = "")
                        if (db.createBooking(booking)) {
                            val bonusEarned = (total * 0.05).toInt()
                            db.addBonusTransaction(user.id, bonusEarned, "earned", "Бонус за бронь в ${hotel.name}")
                            toast("Бронь создана! Начислено $bonusEarned бонусов")
                            showMainScreen()
                        }
                    } catch (e: Exception) { toast("Ошибка в данных") }
                }
            })
        }))

        container.addView(createOutlineButton("⬅️ Назад", Color.WHITE, colorTextSecondary, colorTextSecondary) { showMainScreen() })
    }

    private fun showAddReviewDialog(hotel: Hotel) {
        val user = currentUser ?: return
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 24, 32, 24) }
        val ratingBar = RatingBar(this).apply { numStars = 5; stepSize = 1f; rating = 5f }; layout.addView(ratingBar)
        val etComment = EditText(this).apply { hint = "Ваш отзыв..." }; layout.addView(etComment)
        AlertDialog.Builder(this).setTitle("⭐ Оценить отель").setView(layout)
            .setPositiveButton("Отправить") { _, _ ->
                val rating = ratingBar.rating.toInt()
                val comment = etComment.text.toString()
                if (comment.isNotEmpty()) {
                    if (db.addReview(user.id, hotel.id, hotel.name, rating, comment)) {
                        toast("Спасибо за отзыв!")
                        showHotelDetails(hotel)
                    }
                } else toast("Напишите отзыв")
            }.setNegativeButton("Отмена", null).show()
    }

    // ---------- ДИАЛОГИ АДМИНА ----------
    private fun showAddUserDialog() {
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 24, 32, 24) }
        val etName = EditText(this).apply { hint = "Имя *" }; layout.addView(etName)
        val etEmail = EditText(this).apply { hint = "Email *"; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS }; layout.addView(etEmail)
        val etPhone = EditText(this).apply { hint = "Телефон *"; inputType = InputType.TYPE_CLASS_PHONE }; layout.addView(etPhone)
        val etPass = EditText(this).apply { hint = "Пароль *"; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD }; layout.addView(etPass)
        val etConfirm = EditText(this).apply { hint = "Подтвердите пароль *"; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD }; layout.addView(etConfirm)
        layout.addView(TextView(this).apply { text = "Роль:"; textSize = 16f; setTypeface(null, android.graphics.Typeface.BOLD); setPadding(0, 16, 0, 8) })
        val rgRole = RadioGroup(this).apply { orientation = LinearLayout.HORIZONTAL }
        rgRole.addView(RadioButton(this).apply { text = "👤 Обычный"; id = View.generateViewId(); isChecked = true; setPadding(8, 8, 24, 8) })
        rgRole.addView(RadioButton(this).apply { text = "💎 VIP"; id = View.generateViewId(); setPadding(8, 8, 24, 8) })
        layout.addView(rgRole)

        AlertDialog.Builder(this).setTitle("➕ Добавить клиента").setView(layout)
            .setPositiveButton("Сохранить") { _, _ ->
                val name = etName.text.toString(); val email = etEmail.text.toString(); val phone = etPhone.text.toString()
                val pass = etPass.text.toString(); val confirm = etConfirm.text.toString()
                val role = if ((rgRole.getChildAt(0) as RadioButton).isChecked) "user" else "vip"
                if (name.isEmpty() || email.isEmpty() || phone.isEmpty() || pass.isEmpty()) { toast("Заполните все поля"); return@setPositiveButton }
                if (pass != confirm) { toast("Пароли не совпадают"); return@setPositiveButton }
                if (db.registerUser(name, email, pass, role, phone)) toast("Клиент добавлен") else toast("Ошибка: Email уже используется")
            }.setNegativeButton("Отмена", null).show()
    }

    private fun showAddHotelDialog() {
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 24, 32, 24) }
        layout.addView(EditText(this).apply { hint = "Название" })
        layout.addView(EditText(this).apply { hint = "Город" })
        layout.addView(EditText(this).apply { hint = "Цена"; inputType = InputType.TYPE_CLASS_NUMBER })
        layout.addView(EditText(this).apply { hint = "Рейтинг (0-5)"; inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL })
        layout.addView(EditText(this).apply { hint = "Описание" })
        layout.addView(EditText(this).apply { hint = "Количество номеров"; inputType = InputType.TYPE_CLASS_NUMBER })
        layout.addView(EditText(this).apply { hint = "Удобства (через запятую)" })
        val cbVip = CheckBox(this).apply { text = "VIP отель" }; layout.addView(cbVip)

        AlertDialog.Builder(this).setTitle("➕ Добавить отель").setView(layout)
            .setPositiveButton("Сохранить") { _, _ ->
                try {
                    val hotel = Hotel(
                        name = (layout.getChildAt(0) as EditText).text.toString(),
                        city = (layout.getChildAt(1) as EditText).text.toString(),
                        price = (layout.getChildAt(2) as EditText).text.toString().toDouble(),
                        rating = (layout.getChildAt(3) as EditText).text.toString().toDouble(),
                        description = (layout.getChildAt(4) as EditText).text.toString(),
                        rooms = (layout.getChildAt(5) as EditText).text.toString().toInt(),
                        isVip = cbVip.isChecked,
                        amenities = (layout.getChildAt(6) as EditText).text.toString()
                    )
                    if (db.addHotel(hotel)) toast("Отель добавлен") else toast("Ошибка")
                } catch (e: Exception) { toast("Ошибка в данных") }
            }.setNegativeButton("Отмена", null).show()
    }

    private fun showEditHotelDialog(hotel: Hotel) {
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 24, 32, 24) }
        layout.addView(EditText(this).apply { hint = "Название"; setText(hotel.name) })
        layout.addView(EditText(this).apply { hint = "Город"; setText(hotel.city) })
        layout.addView(EditText(this).apply { hint = "Цена"; setText(hotel.price.toString()); inputType = InputType.TYPE_CLASS_NUMBER })
        layout.addView(EditText(this).apply { hint = "Рейтинг"; setText(hotel.rating.toString()); inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL })
        layout.addView(EditText(this).apply { hint = "Описание"; setText(hotel.description) })
        layout.addView(EditText(this).apply { hint = "Номеров"; setText(hotel.rooms.toString()); inputType = InputType.TYPE_CLASS_NUMBER })
        layout.addView(EditText(this).apply { hint = "Удобства"; setText(hotel.amenities ?: "") })
        val cbVip = CheckBox(this).apply { text = "VIP отель"; isChecked = hotel.isVip }; layout.addView(cbVip)

        AlertDialog.Builder(this).setTitle("✏️ Редактировать отель").setView(layout)
            .setPositiveButton("Сохранить") { _, _ ->
                try {
                    val updated = hotel.copy(
                        name = (layout.getChildAt(0) as EditText).text.toString(),
                        city = (layout.getChildAt(1) as EditText).text.toString(),
                        price = (layout.getChildAt(2) as EditText).text.toString().toDouble(),
                        rating = (layout.getChildAt(3) as EditText).text.toString().toDouble(),
                        description = (layout.getChildAt(4) as EditText).text.toString(),
                        rooms = (layout.getChildAt(5) as EditText).text.toString().toInt(),
                        isVip = cbVip.isChecked,
                        amenities = (layout.getChildAt(6) as EditText).text.toString()
                    )
                    if (db.updateHotel(updated)) toast("Отель обновлен") else toast("Ошибка")
                } catch (e: Exception) { toast("Ошибка в данных") }
            }.setNegativeButton("Отмена", null).show()
    }
}